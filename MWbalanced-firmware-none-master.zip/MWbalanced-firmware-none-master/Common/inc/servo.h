#ifndef _SERVO_H
#define _SERVO_H



extern void ServoInit(void);
extern void ServoCtr(unsigned char speed,unsigned char channel);

#endif

