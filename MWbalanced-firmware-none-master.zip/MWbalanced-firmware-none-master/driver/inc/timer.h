
#ifndef _TIMER_H_
#define _TIMER_H_

#include "IAP15W4K61S4.h"

void Timer0Init(void);
void Timer1Init(void);
void Timer3Timer4Init(void)	;

#endif