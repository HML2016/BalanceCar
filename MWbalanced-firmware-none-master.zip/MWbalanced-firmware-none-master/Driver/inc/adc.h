

#ifndef __ADC_H__
#define __ADC_H__

#include "IAP15W4K61S4.h"

void ADCInit();
unsigned char GetADCResult(void);


#endif